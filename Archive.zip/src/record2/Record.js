import React, { Component } from 'react';
import { ReactMic } from 'react-mic';
import "./Record.css";

class Record extends Component {
  constructor(props) {
    super(props);
    this.state = {
      blobURL: null,
      isRecording: false,
      isPaused: false,
    }
    this.startOrPauseRecording = this.startOrPauseRecording.bind(this);
    this.stopRecording = this.stopRecording.bind(this);
    this.onStop = this.onStop.bind(this);
  }

  startOrPauseRecording() {
    const { isPaused, isRecording } = this.state;

    if (isPaused) {
      this.setState({ isPaused: false })
    } else if(isRecording) {
      this.setState({ isPaused: true })
    } else {
      this.setState({ isRecording: true })
    }
  }

  stopRecording() {
    this.setState({ isRecording: false });
  }
  //
  // onSave=(blobObject) => {
  // }

  // onStart=() => {
  //   console.log('You can tap into the onStart callback');
  // }

  onData(recordedBlob) {
    console.log('chunk of real-time data is: ', recordedBlob);
  }

  onStop(blobObject) {
    this.setState({ blobURL : blobObject.blobURL });
  }


  render() {
    return (
      <div>
        <ReactMic
          className="oscilloscope"
          record={this.state.isRecording}
          pause={this.state.isPaused}
          backgroundColor="white"
          visualSetting="sinewave"
          audioBitsPerSecond= {128000}
          onStop={this.onStop}
          onStart={this.onStart}
          onSave={this.onSave}
          onData={this.onData}
          width="300"
          strokeColor="#000000" />
        <div>
          <audio ref="audioSource" controls="controls" src={this.state.blobURL} download="audio.wav"></audio>
        </div>
        <br />
        <br />
        <button
          onClick={this.startOrPauseRecording}>
          { (this.state.isRecording && !this.state.isPaused )? <img alt="Pause" className="Icon" src="baseline-pause-24px.svg" /> : <img alt="Record" className="Icon" src="baseline-mic-24px.svg" /> }
        </button>
        <button
          disabled={!this.state.isRecording}
          onClick={this.stopRecording}>
          <img
            alt="Stop recording"
            className="Icon"
            src="baseline-save-24px.svg"
          />
        </button>
      </div>
    );
  }
}

export default Record
