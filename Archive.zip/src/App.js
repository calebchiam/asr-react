import React, { Component } from "react";
import "./App.css";
import Interface from "./interface/Interface";

class App extends Component {
  render() {
    return (
      <Interface />
    );
  }
}

export default App;
