import React, { Component } from 'react';
import {
  Route,
  NavLink,
  HashRouter
} from "react-router-dom";
import Upload from "../upload/Upload";
import Record from "../record2/Record";
import "./Input.css";

class Input extends Component {
  render() {
    return(
      <HashRouter>
        <div>
          <ul className="header">
            <li><NavLink exact to="/">Upload audio</NavLink></li>
            <li><NavLink to="/record">Record clip</NavLink></li>
          </ul>
          <div className="content">
            <Route
              exact path="/"
              render={() => <Upload {...this.props} /> }
            />
            <Route
              path="/record"
              render={() => <Record {...this.props} /> }
            />
          </div>
        </div>


      </HashRouter>
    )
  }
}

export default Input;
